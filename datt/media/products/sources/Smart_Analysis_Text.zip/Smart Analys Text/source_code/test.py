
from nlp_utils import sentiment_analysis, detect_text_language, choose_best_sentiment_engine, expand_emojis
from textblob import TextBlob
from nltk.sentiment import SentimentIntensityAnalyzer
import nltk

try:
    nltk.download('vader_lexicon', quiet=True)
except:
    pass

text = "- Yeh aap bahut accha hai 😄"

print(f"Original Text: '{text}'")
lang = detect_text_language(text)
print(f"Detected Language: {lang}")

engine_info = choose_best_sentiment_engine(text)
print(f"Chosen Engine: {engine_info['engine']}")

# Test TextBlob polarity directly on components
target = text.strip()
expanded = expand_emojis(target)
print(f"Target: '{target}'")
print(f"Expanded: '{expanded}'")

tb_pol = TextBlob(expanded).sentiment.polarity
v_pol = SentimentIntensityAnalyzer().polarity_scores(expanded)['compound']

print(f"TextBlob Polarity: {tb_pol}")
print(f"VADER Polarity: {v_pol}")

# Check with the full engine
result = sentiment_analysis(text, engine='textblob')
print(f"Sentiment Analysis (TextBlob): {result}")

# Check word by word for negative surprise
for word in expanded.split():
    print(f"Word: '{word}' -> Polarity: {TextBlob(word).sentiment.polarity}")
