import unittest
from collections import Counter
from unittest.mock import patch

import nlp_utils


class TestNlpUtils(unittest.TestCase):
    def test_normalize_text(self):
        # Test lowercase and punctuation removal
        text = "Hello, World! 123"
        normalized = nlp_utils.normalize_text(text, lowercase=True, remove_punct=True)
        self.assertEqual(normalized, "hello world")
        
        # Test keeping case
        normalized_case = nlp_utils.normalize_text(text, lowercase=False, remove_punct=True)
        self.assertEqual(normalized_case, "Hello World")
        
        # Test keeping punctuation
        normalized_punct = nlp_utils.normalize_text("Hello, World!", lowercase=True, remove_punct=False)
        self.assertEqual(normalized_punct, "hello, world!")

    def test_tokenize_and_preprocess_edge_cases(self):
        text = "Hello, HELLO!!! 123\nThis is\t a test."

        # Test with custom stop words
        custom_stop = {"this", "is", "a"}
        filtered = nlp_utils.preprocess_text(text, custom_stop_words=custom_stop)
        self.assertEqual(filtered, ["hello", "hello", "test"])

    def test_word_statistics_and_top10(self):
        words = ["apple", "banana", "apple", "orange", "banana", "apple"]
        total, unique, freq = nlp_utils.word_statistics(words)

        self.assertEqual(total, 6)
        self.assertEqual(unique, 3)
        self.assertIsInstance(freq, Counter)
        self.assertEqual(freq["apple"], 3)
        self.assertEqual(freq["banana"], 2)
        self.assertEqual(freq["orange"], 1)

        top10 = nlp_utils.top_10_words(freq)
        self.assertEqual(top10[0], ("apple", 3))
        self.assertEqual(len(top10), 3)  # Only 3 unique words

    def test_sentiment_bucket_boundaries(self):
        # Test default thresholds
        self.assertEqual(nlp_utils.classify_polarity(0.1), "neutral")
        self.assertEqual(nlp_utils.classify_polarity(-0.1), "neutral")
        self.assertEqual(nlp_utils.classify_polarity(0.1001), "positive")
        self.assertEqual(nlp_utils.classify_polarity(-0.1001), "negative")
        
        # Test custom thresholds
        self.assertEqual(nlp_utils.classify_polarity(0.2, pos_threshold=0.2, neg_threshold=-0.2), "neutral")
        self.assertEqual(nlp_utils.classify_polarity(0.3, pos_threshold=0.2, neg_threshold=-0.2), "positive")
        self.assertEqual(nlp_utils.classify_polarity(-0.3, pos_threshold=0.2, neg_threshold=-0.2), "negative")

    def test_sentiment_analysis(self):
        text = "I love this! It's amazing. But sometimes it fails."
        result = nlp_utils.sentiment_analysis(text)
        
        self.assertIn("positive", result)
        self.assertIn("negative", result)
        self.assertIn("neutral", result)
        self.assertIsInstance(result["positive"], list)
        self.assertIsInstance(result["negative"], list)
        self.assertIsInstance(result["neutral"], list)

    def test_textblob_maps_mixed_sentiment_to_neutral(self):
        result = nlp_utils.sentiment_analysis("I love the design, but I hate the crashes.", engine="textblob")
        self.assertEqual(result["negative"], ["I love the design, but I hate the crashes."])

    def test_vader_handles_common_emojis(self):
        positive = nlp_utils.sentiment_analysis("😀", engine="vader")
        negative = nlp_utils.sentiment_analysis("😡", engine="vader")

        self.assertEqual(positive["positive"], ["😀"])
        self.assertEqual(negative["negative"], ["😡"])

    def test_multilingual_sentiment_with_mocked_pipeline(self):
        original_has_transformers = nlp_utils.HAS_TRANSFORMERS
        nlp_utils.HAS_TRANSFORMERS = True

        def fake_pipeline(sentence):
            mapping = {
                "Tuyet voi qua.": {"label": "positive", "score": 0.98},
                "That bai roi.": {"label": "negative", "score": 0.96},
                "Binh thuong.": {"label": "neutral", "score": 0.80},
                "Toi rat thich giao dien": {"label": "positive", "score": 0.97},
                "toi ghet toc do xu ly.": {"label": "negative", "score": 0.97},
                "Toi rat thich giao dien, nhung toi ghet toc do xu ly.": {"label": "neutral", "score": 0.60},
            }
            return [mapping[sentence]]

        try:
            with patch("nlp_utils.has_sentencepiece_support", return_value=True):
                with patch("nlp_utils.get_transformers_sentiment_pipeline", return_value=fake_pipeline):
                    text = "Tuyet voi qua. That bai roi. Binh thuong."
                    result = nlp_utils.sentiment_analysis(text, engine="multilingual")

            self.assertEqual(result["positive"], ["Tuyet voi qua."])
            self.assertEqual(result["negative"], ["That bai roi."])
            self.assertEqual(result["neutral"], ["Binh thuong."])
        finally:
            nlp_utils.HAS_TRANSFORMERS = original_has_transformers

    def test_multilingual_sentiment_maps_mixed_clauses_to_neutral(self):
        original_has_transformers = nlp_utils.HAS_TRANSFORMERS
        nlp_utils.HAS_TRANSFORMERS = True

        def fake_pipeline(sentence):
            mapping = {
                "toi ghet toc do xu ly.": {"label": "negative", "score": 0.97},
            }
            return [mapping[sentence]]

        try:
            with patch("nlp_utils.has_sentencepiece_support", return_value=True):
                with patch("nlp_utils.get_transformers_sentiment_pipeline", return_value=fake_pipeline):
                    result = nlp_utils.sentiment_analysis(
                        "Toi rat thich giao dien, nhung toi ghet toc do xu ly.",
                        engine="multilingual",
                    )
            self.assertEqual(
                result["negative"],
                ["Toi rat thich giao dien, nhung toi ghet toc do xu ly."],
            )
        finally:
            nlp_utils.HAS_TRANSFORMERS = original_has_transformers

    def test_get_sentiment_focus_text_prefers_clause_after_but(self):
        self.assertEqual(
            nlp_utils.get_sentiment_focus_text("abc but xyz"),
            "xyz",
        )
        self.assertEqual(
            nlp_utils.get_sentiment_focus_text("toi thay on nhung hoi cham"),
            "hoi cham",
        )

    def test_detect_text_language_prefers_multilingual_for_vietnamese(self):
        language = nlp_utils.detect_text_language("Tôi rất thích sản phẩm này. Nó tuyệt vời.")
        self.assertEqual(language, "multilingual")

    def test_detect_text_language_prefers_english_for_english_text(self):
        language = nlp_utils.detect_text_language("I really love this product and it works great.")
        self.assertEqual(language, "english")

    def test_detect_text_language_prefers_multilingual_for_common_foreign_latin_phrases(self):
        self.assertEqual(nlp_utils.detect_text_language("te amo"), "multilingual")
        self.assertEqual(nlp_utils.detect_text_language("merci"), "multilingual")
        self.assertEqual(nlp_utils.detect_text_language("Yeh app bahut accha hai"), "multilingual")

    def test_detect_text_language_uses_langdetect_when_available(self):
        with patch("nlp_utils.HAS_LANGDETECT", True):
            with patch("nlp_utils.langdetect_detect", return_value="fr"):
                self.assertEqual(nlp_utils.detect_text_language("merci beaucoup"), "multilingual")
            with patch("nlp_utils.langdetect_detect", return_value="en"):
                self.assertEqual(nlp_utils.detect_text_language("this is clearly english"), "english")

    def test_detect_text_language_falls_back_when_langdetect_fails(self):
        with patch("nlp_utils.HAS_LANGDETECT", True):
            with patch("nlp_utils.langdetect_detect", side_effect=nlp_utils.LangDetectException(0, "fail")):
                self.assertEqual(nlp_utils.detect_text_language("te amo"), "multilingual")

    def test_choose_best_sentiment_engine_prefers_vader_for_social_english(self):
        decision = nlp_utils.choose_best_sentiment_engine("OMG this is amazing!!! 😀😀")
        self.assertEqual(decision["engine"], "vader")

    def test_choose_best_sentiment_engine_prefers_multilingual_for_vietnamese(self):
        original_has_transformers = nlp_utils.HAS_TRANSFORMERS
        nlp_utils.HAS_TRANSFORMERS = True
        try:
            with patch("nlp_utils.has_sentencepiece_support", return_value=True):
                decision = nlp_utils.choose_best_sentiment_engine("Tôi ghét lỗi này nhưng giao diện rất đẹp.")
            self.assertEqual(decision["engine"], "multilingual")
        finally:
            nlp_utils.HAS_TRANSFORMERS = original_has_transformers

    def test_sentiment_analysis_auto_uses_resolved_engine(self):
        with patch("nlp_utils.choose_best_sentiment_engine", return_value={"engine": "vader", "language": "english", "reason": "test"}):
            with patch("nlp_utils.sentiment_analysis_vader", return_value={"positive": ["ok"], "neutral": [], "negative": []}):
                result = nlp_utils.sentiment_analysis("test", engine="auto")
        self.assertEqual(result["positive"], ["ok"])

    def test_empty_input_handling(self):
        # Test empty text
        words = nlp_utils.preprocess_text("")
        self.assertEqual(words, [])
        
        result = nlp_utils.sentiment_analysis("")
        self.assertEqual(result, {"positive": [], "neutral": [], "negative": []})

    def test_top10_with_few_words(self):
        words = ["test"]
        _, _, freq = nlp_utils.word_statistics(words)
        top10 = nlp_utils.top_10_words(freq)
        self.assertEqual(len(top10), 1)
        self.assertEqual(top10[0], ("test", 1))

    def test_polars_analytics_features(self):
        text = (
            "Free cash now!!! Click here now. "
            "I love this product very much. "
            "This product works really well. "
            "Limited time offer, buy now!!!"
        )

        word_rows = nlp_utils.polars_word_frequency(text, top_n=5)
        keyword_rows = nlp_utils.polars_keyword_extraction(text, top_n=5)
        sentence_analytics = nlp_utils.polars_sentence_analytics(text)
        ngrams = nlp_utils.polars_ngram_frequency(text, top_n=5)
        spam_rows = nlp_utils.polars_spam_filter(text)

        self.assertTrue(any(row["word"] == "product" for row in word_rows))
        self.assertTrue(any(row["keyword"] == "product" for row in keyword_rows))
        self.assertGreaterEqual(sentence_analytics["summary"]["sentence_count"], 3)
        self.assertIsInstance(ngrams["bigrams"], list)
        self.assertGreaterEqual(len(spam_rows["spam"]), 1)


if __name__ == "__main__":
    unittest.main()
