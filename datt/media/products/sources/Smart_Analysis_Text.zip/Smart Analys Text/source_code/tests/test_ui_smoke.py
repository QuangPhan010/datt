import os
import unittest

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

from PyQt5.QtWidgets import QApplication

from main import MainApp


class FakeController:
    def remove_stopwords(self, text):
        return [text]

    def statistics(self, text):
        return 1, 1, {text: 1}

    def top10(self, text):
        return [(text, 1)]

    def analyze_sentiment(self, text):
        return {"positive": [], "neutral": [text], "negative": []}


class TestUiSmoke(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])

    def test_buttons_enable_when_input_exists(self):
        window = MainApp()
        window.inputTextEdit.setPlainText("hello")
        window.update_text_info()

        self.assertTrue(window.stopwordsButton.isEnabled())
        self.assertTrue(window.top10Button.isEnabled())
        self.assertTrue(window.sentimentButton.isEnabled())

    def test_multilingual_engine_is_available(self):
        window = MainApp()
        engines = [window.sentimentEngineCombo.itemText(i) for i in range(window.sentimentEngineCombo.count())]

        self.assertIn("Multilingual XLM-R", engines)

    def test_auto_detect_engine_is_default(self):
        window = MainApp()
        self.assertEqual(window.sentimentEngineCombo.currentText(), "Auto Detect (Smart)")


if __name__ == "__main__":
    unittest.main()
