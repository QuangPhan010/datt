"""
Text Analysis Service - Business logic layer for NLP operations.
Separates UI concerns from analysis logic.
"""

import nlp_utils


class TextAnalysisService:
    """
    Service class for text analysis operations.
    Provides a clean interface for NLP tasks.
    """

    def __init__(self):
        self.last_sentiment_result = None

    def preprocess(self, text):
        """Preprocess text: clean, lowercase, remove stopwords."""
        if not text.strip():
            return []
        return nlp_utils.preprocess_text(text)

    def get_top_words(self, text, n=10):
        """Get top N most frequent words."""
        words = self.preprocess(text)
        _, _, frequency = nlp_utils.word_statistics(words)
        return nlp_utils.top_10_words(frequency)[:n]

    def get_word_frequency(self, text, n=15):
        """Get word frequency with Polars."""
        if not text.strip():
            return []
        return nlp_utils.polars_word_frequency(text, top_n=n)

    def get_keywords(self, text, n=10):
        """Extract top keywords with Polars."""
        if not text.strip():
            return []
        return nlp_utils.polars_keyword_extraction(text, top_n=n)

    def get_sentence_analytics(self, text):
        """Analyze sentence lengths with Polars."""
        if not text.strip():
            return {'summary': {}, 'rows': []}
        return nlp_utils.polars_sentence_analytics(text)

    def get_ngram_frequency(self, text):
        """Get bigram/trigram frequency with Polars."""
        if not text.strip():
            return {'bigrams': [], 'trigrams': []}
        return nlp_utils.polars_ngram_frequency(text)

    def filter_spam_sentences(self, text):
        """Filter spam-like sentences with Polars."""
        if not text.strip():
            return {'spam': [], 'clean': []}
        return nlp_utils.polars_spam_filter(text)

    def analyze_sentiment(self, text, engine='textblob'):
        """Analyze sentiment of text with specified engine.
        
        Parameters:
        - text: Input text to analyze
        - engine: 'textblob' (default), 'vader', 'distilbert', or 'multilingual'
        """
        if not text.strip():
            return nlp_utils.empty_sentiment_result()
        result = nlp_utils.sentiment_analysis(text, engine=engine)
        self.last_sentiment_result = result
        return result

    def get_negative_sentences(self):
        """Get previously analyzed negative sentences."""
        if not self.last_sentiment_result:
            return []
        return self.last_sentiment_result.get('negative', [])

    def format_preprocess_result(self, words):
        """Format preprocess results for display."""
        return "WORDS AFTER REMOVING STOPWORDS:\n" + ", ".join(words)

    def format_top_words_result(self, top_words):
        """Format top words results for display."""
        result = ["TOP 10 WORDS:"]
        for w, c in top_words:
            result.append(f"{w} : {c}")
        return "\n".join(result)

    def format_word_frequency_result(self, rows):
        """Format Polars word-frequency results."""
        if not rows:
            return "WORD FREQUENCY:\nNo words found."
        result = ["WORD FREQUENCY:"]
        for row in rows:
            result.append(f"{row['word']} : {row['count']}")
        return "\n".join(result)

    def format_keyword_result(self, rows):
        """Format keyword-extraction results."""
        if not rows:
            return "TOP KEYWORDS:\nNo keywords found."
        result = ["TOP KEYWORDS:"]
        for row in rows:
            result.append(f"{row['keyword']} : count={row['count']}, score={row['score']}")
        return "\n".join(result)

    def format_sentence_analytics_result(self, analytics):
        """Format sentence analytics results."""
        summary = analytics['summary']
        rows = analytics['rows']
        if not rows:
            return "SENTENCE ANALYTICS:\nNo sentences found."

        result = [
            "SENTENCE ANALYTICS:",
            f"Sentence count: {summary['sentence_count']}",
            f"Average chars: {summary['avg_chars']}",
            f"Average words: {summary['avg_words']}",
            f"Max chars: {summary['max_chars']}",
            f"Min chars: {summary['min_chars']}",
            "",
            "Longest sentences:",
        ]
        for row in rows[:5]:
            result.append(
                f"- ({row['char_length']} chars / {row['word_length']} words) {row['sentence']}"
            )
        return "\n".join(result)

    def format_ngram_frequency_result(self, ngrams):
        """Format bigram/trigram frequency results."""
        result = ["N-GRAM FREQUENCY:", "", "Bigrams:"]
        if ngrams['bigrams']:
            for row in ngrams['bigrams']:
                result.append(f"{row['ngram']} : {row['count']}")
        else:
            result.append("No bigrams found.")

        result.append("")
        result.append("Trigrams:")
        if ngrams['trigrams']:
            for row in ngrams['trigrams']:
                result.append(f"{row['ngram']} : {row['count']}")
        else:
            result.append("No trigrams found.")
        return "\n".join(result)

    def format_spam_filter_result(self, spam_result):
        """Format spam-filter results."""
        spam_rows = spam_result['spam']
        clean_rows = spam_result['clean']
        result = [
            f"Spam sentences: {len(spam_rows)}",
            f"Clean sentences: {len(clean_rows)}",
            "",
            "FLAGGED SPAM SENTENCES:",
        ]
        if spam_rows:
            for row in spam_rows:
                result.append(f"- score={row['spam_score']} | {row['sentence']}")
        else:
            result.append("No spam sentences detected.")
        return "\n".join(result)

    def format_sentiment_result(self, sentiment):
        """Format sentiment analysis results for display."""
        result = []
        result.append(f"Positive sentences: {len(sentiment['positive'])}")
        result.append(f"Neutral sentences: {len(sentiment['neutral'])}")
        result.append(f"Negative sentences: {len(sentiment['negative'])}")
        return "\n".join(result)

    def format_negative_sentences_result(self, negatives):
        """Format negative sentences for display."""
        if not negatives:
            return "No negative sentences found."
        result = ["NEGATIVE SENTENCES:\n"]
        for s in negatives:
            result.append("- " + s)
        return "\n".join(result)
