# Setup Notes

## 1) Install dependencies

```bash
pip install -r requirements.txt
```

## 2) Download required NLTK corpora

```bash
python -m nltk.downloader stopwords punkt
```

Optional (for VADER sentiment model):

```bash
python -m nltk.downloader vader_lexicon
```

Optional (for DistilBERT and multilingual sentiment models):

```bash
pip install transformers torch sentencepiece
```

If you use the multilingual `XLM-R` sentiment model in the `ck` conda env, install it there explicitly:

```bash
conda activate ck
pip install transformers torch sentencepiece
```

## 3) Run app

```bash
python main.py
```

## 4) Run tests

```bash
python -m unittest discover -s tests -v
```
