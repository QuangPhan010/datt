# Import các thư viện cần thiết
import re  # Thư viện cho biểu thức chính quy, dùng để làm sạch văn bản
import logging
import importlib.util
from textblob import TextBlob  # Thư viện hỗ trợ xử lý NLP, đặc biệt mạnh cho phân tích cảm xúc
from nltk.corpus import stopwords  # Thư viện NLTK cung cấp danh sách các từ dừng (stopwords)
from nltk.sentiment import SentimentIntensityAnalyzer  # Import VADER sentiment analyzer
import nltk
from collections import Counter

try:
    from langdetect import detect as langdetect_detect
    from langdetect.lang_detect_exception import LangDetectException
    HAS_LANGDETECT = True
except ImportError:
    langdetect_detect = None
    LangDetectException = Exception
    HAS_LANGDETECT = False

logger = logging.getLogger(__name__)
DISTILBERT_MODEL_NAME = "distilbert-base-uncased-finetuned-sst-2-english"
MULTILINGUAL_SENTIMENT_MODEL_NAME = "cardiffnlp/twitter-xlm-roberta-base-sentiment"
_SENTIMENT_PIPELINES = {}
SENTIMENT_BUCKETS = ("positive", "neutral", "negative")

# Try to import transformers for DistilBERT, but make it optional
try:
    from transformers import pipeline
    HAS_TRANSFORMERS = True
except ImportError:
    HAS_TRANSFORMERS = False

try:
    import polars as pl
    HAS_POLARS = True
except ImportError:
    HAS_POLARS = False

# Tải và khởi tạo danh sách các từ dừng của tiếng Anh (ví dụ: 'a', 'the', 'is')
# Chuyển danh sách thành một `set` để tăng tốc độ truy vấn (tra cứu O(1) thay vì O(n))
STOP_WORDS = None
EMOJI_SENTIMENT_MAP = {
    "😀": " smile ",
    "😃": " smile ",
    "😄": " smile ",
    "😁": " smile ",
    "🙂": " smile ",
    "😊": " happy ",
    "😍": " love ",
    "🥰": " love ",
    "😘": " love ",
    "😂": " laugh ",
    "🤣": " laugh ",
    "👍": " good ",
    "❤️": " love ",
    "❤": " love ",
    "😢": " sad ",
    "😭": " cry ",
    "😞": " sad ",
    "😔": " sad ",
    "😡": " angry ",
    "😠": " angry ",
    "👎": " bad ",
    "💔": " bad ",
}
# Use Vietnamese-specific base letters only to avoid misclassifying
# other Latin languages (e.g., Spanish/French) as Vietnamese.
VIETNAMESE_UNIQUE_CHARACTERS = set("ăâđêôơư")
ENGLISH_HINT_WORDS = {
    "the", "and", "is", "are", "was", "were", "this", "that", "with", "have",
    "love", "hate", "good", "bad", "amazing", "terrible", "great", "awful",
}
VIETNAMESE_HINT_WORDS = {
    "toi", "ban", "rat", "khong", "co", "la", "nhung", "mot", "nay", "kia",
    "yeu", "ghet", "tot", "te", "tuyet", "voi", "buon", "vui", "that", "bai",
}
NON_ENGLISH_HINT_WORDS = {
    "te", "amo", "gracias", "hola", "adios", "merci", "bonjour", "salut",
    "bahut", "accha", "acha", "hai", "shukriya", "por", "favor", "ciao",
    "badhiya", "mast", "zabardast", "maza", "shandar", "ghatiya", "bekar",
    "pagal", "chutiya", "bakwas", "kamal", "dhanyawad", "suprabhat",
    "aap", "yeh", "app", "tum", "main", "hum", "kaise", "thi", "tha",
}
LANGUAGE_CODE_TO_NAME = {
    "en": "English",
    "vi": "Vietnamese",
    "fr": "French",
    "de": "German",
    "es": "Spanish",
    "it": "Italian",
    "pt": "Portuguese",
    "ru": "Russian",
    "zh": "Chinese",
    "zh-cn": "Chinese (Simplified)",
    "zh-tw": "Chinese (Traditional)",
    "ja": "Japanese",
    "ko": "Korean",
    "th": "Thai",
    "id": "Indonesian",
    "ms": "Malay",
    "hi": "Hindi (India)",
    "ar": "Arabic",
    "tr": "Turkish",
    "nl": "Dutch",
    "pl": "Polish",
    "sv": "Swedish",
    "no": "Norwegian",
    "da": "Danish",
    "fi": "Finnish",
    "uk": "Ukrainian",
    "cs": "Czech",
    "ro": "Romanian",
    "el": "Greek",
    "he": "Hebrew",
}
LANGUAGE_HINT_WORDS = {
    "Italian": {
        "ciao", "buongiorno", "buonasera", "grazie", "prego", "come", "stai",
        "tutti", "buona", "giornata", "oggi", "amore", "bene", "molto",
    },
    "Spanish": {
        "hola", "gracias", "adios", "todos", "buen", "dia", "buenos",
        "dias", "buenas", "tardes", "por", "favor", "amor", "muy",
    },
    "French": {
        "bonjour", "merci", "salut", "au", "revoir", "tout", "monde",
        "bonne", "journee", "s'il", "vous", "plait", "amour", "tres",
    },
    "Hindi (India)": {
        "namaste", "dhanyawad", "shukriya", "aap", "tum", "hum", "kaise",
        "hai", "acha", "accha", "bahut", "pyaar", "dost",
    },
}

def load_stopwords():
    """
    Load NLTK stopwords safely with error handling.
    """
    global STOP_WORDS
    if STOP_WORDS is not None:
        return STOP_WORDS
    try:
        STOP_WORDS = set(stopwords.words("english"))
        return STOP_WORDS
    except LookupError:
        print("NLTK stopwords corpus not found. Downloading...")
        try:
            nltk.download("stopwords", quiet=True)
            STOP_WORDS = set(stopwords.words("english"))
            return STOP_WORDS
        except Exception as e:
            print(f"Failed to download NLTK stopwords: {e}")
            # Fallback to a basic set of common stopwords
            STOP_WORDS = {"a", "an", "the", "and", "or", "but", "in", "on", "at", "to", "for", "of", "with", "by", "is", "are", "was", "were", "be", "been", "being", "have", "has", "had", "do", "does", "did", "will", "would", "could", "should", "may", "might", "must", "can", "shall"}
            return STOP_WORDS

# Định nghĩa ngưỡng để phân loại cảm xúc dựa trên điểm `polarity` của TextBlob
# Polarity là một giá trị float trong khoảng [-1.0, 1.0]
POS_THRESHOLD = 0.1  # Nếu polarity > 0.1, câu được xem là tích cực
NEG_THRESHOLD = -0.1 # Nếu polarity < -0.1, câu được xem là tiêu cực
# Các câu có polarity trong khoảng [-0.1, 0.1] được xem là trung tính

def get_sentiment_thresholds():
    """Get current sentiment thresholds."""
    return POS_THRESHOLD, NEG_THRESHOLD

def classify_polarity(polarity, pos_threshold=None, neg_threshold=None):
    """
    Classify polarity into positive, negative, or neutral based on thresholds.
    """
    if pos_threshold is None:
        pos_threshold = POS_THRESHOLD
    if neg_threshold is None:
        neg_threshold = NEG_THRESHOLD
    
    if polarity > pos_threshold:
        return "positive"
    elif polarity < neg_threshold:
        return "negative"
    else:
        return "neutral"


def empty_sentiment_result():
    """
    Create the standard sentiment result structure.
    """
    return {bucket: [] for bucket in SENTIMENT_BUCKETS}


CONTRASTIVE_CONJUNCTION_PATTERN = re.compile(
    r"\b(?:but|however|though|although|yet|while|nhung|nhưng|tuy|dau|dẫu|mà)\b",
    flags=re.IGNORECASE,
)


def get_sentiment_focus_text(text):
    """
    When a contrastive conjunction exists, focus sentiment on the trailing clause.
    Also strip leading symbols (like bullet points) that can confuse engines.
    """
    if not text:
        return text

    matches = list(CONTRASTIVE_CONJUNCTION_PATTERN.finditer(text))
    if not matches:
        return text.strip(" ,;:-")

    focused_text = text[matches[-1].end():].strip(" ,;:-")
    return focused_text or text.strip(" ,;:-")


def split_sentiment_clauses(text):
    """
    Split a sentence into smaller clauses to detect mixed sentiment.
    """
    if not text.strip():
        return []

    parts = re.split(
        CONTRASTIVE_CONJUNCTION_PATTERN.pattern + r"|[;,]+",
        text,
        flags=re.IGNORECASE,
    )
    return [part.strip() for part in parts if part.strip()]


def is_mixed_sentiment_labels(labels):
    """
    Return True when both positive and negative labels are present.
    """
    unique_labels = set(labels)
    return "positive" in unique_labels and "negative" in unique_labels


def expand_emojis(text):
    """
    Replace common emojis with sentiment-bearing words so engines can score them.
    """
    if not text:
        return text

    expanded_text = text
    for emoji_char, replacement in EMOJI_SENTIMENT_MAP.items():
        expanded_text = expanded_text.replace(emoji_char, replacement)

    # Normalize repeated spaces introduced by emoji replacements.
    return re.sub(r"\s+", " ", expanded_text).strip()


def require_polars():
    """
    Ensure Polars is available for analytics features.
    """
    if not HAS_POLARS:
        raise RuntimeError("Polars is not installed. Install it with: pip install polars")


def split_sentences(text):
    """
    Split text into sentences using TextBlob with a simple fallback.
    """
    if not text.strip():
        return []

    blob = TextBlob(text)
    sentences = [str(sentence).strip() for sentence in blob.sentences if str(sentence).strip()]
    if sentences:
        return sentences

    return [segment.strip() for segment in re.split(r"[.!?\n]+", text) if segment.strip()]


def get_transformers_sentiment_pipeline(model_name):
    """
    Lazily create and cache a transformers sentiment pipeline.
    """
    if not HAS_TRANSFORMERS:
        raise RuntimeError("Transformers is not installed. Install it with: pip install transformers torch")

    if model_name not in _SENTIMENT_PIPELINES:
        _SENTIMENT_PIPELINES[model_name] = pipeline("sentiment-analysis", model=model_name)

    return _SENTIMENT_PIPELINES[model_name]


def has_transformers_support():
    """
    Return whether transformer-based sentiment models can be used.
    """
    return HAS_TRANSFORMERS


def has_sentencepiece_support():
    """
    Return whether SentencePiece is available for multilingual tokenizers such as XLM-R.
    """
    return importlib.util.find_spec("sentencepiece") is not None


def has_multilingual_transformer_support():
    """
    Return whether the multilingual XLM-R sentiment model can be loaded safely.
    """
    return has_transformers_support() and has_sentencepiece_support()


def map_transformer_sentiment_label(label):
    """
    Normalize common transformer sentiment labels to positive/neutral/negative.
    """
    normalized = str(label).strip().lower()

    if normalized in {"positive", "pos", "label_2", "2", "5 stars", "4 stars"}:
        return "positive"
    if normalized in {"negative", "neg", "label_0", "0", "1 star", "2 stars"}:
        return "negative"
    if normalized in {"neutral", "neu", "label_1", "1", "3 stars"}:
        return "neutral"

    if "positive" in normalized or normalized.endswith("_2"):
        return "positive"
    if "negative" in normalized or normalized.endswith("_0"):
        return "negative"
    if "neutral" in normalized or normalized.endswith("_1"):
        return "neutral"

    return "neutral"


def detect_text_language(text):
    """
    Detect whether input is likely English or multilingual/non-English.
    Prefer local heuristics for short or ambiguous text (like Hinglish/Vietnamese),
    then fall back to langdetect.
    """
    stripped = text.strip()
    if not stripped:
        return "unknown"

    lowered = stripped.lower()
    alpha_chars = [char for char in lowered if char.isalpha()]
    if not alpha_chars:
        return "unknown"

    # 1. First, use custom heuristics (hints) to catch Hinglish/Vietnamese
    # which langdetect often misidentifies as English.
    words = re.findall(r"[a-zA-ZÀ-ỹ]+", lowered)
    english_hits = sum(1 for word in words if word in ENGLISH_HINT_WORDS)
    vietnamese_hits = sum(1 for word in words if word in VIETNAMESE_HINT_WORDS)
    non_english_hits = sum(1 for word in words if word in NON_ENGLISH_HINT_WORDS)
    vietnamese_char_hits = sum(1 for char in lowered if char in VIETNAMESE_UNIQUE_CHARACTERS)
    
    total_len = len(alpha_chars)
    ascii_ratio = sum(1 for char in alpha_chars if ord(char) < 128) / total_len if total_len > 0 else 1.0

    if vietnamese_char_hits > 0 or vietnamese_hits >= 2:
        return "multilingual"
    if non_english_hits >= 1 and english_hits <= 1: # Catch Hinglish even if 1 English word exists
        return "multilingual"

    # 2. Fallback to langdetect for longer or more standard text.
    if HAS_LANGDETECT:
        try:
            detected_lang = langdetect_detect(stripped)
            if detected_lang == "en":
                # For ambiguity, check if we have any non-English hints at all
                if non_english_hits > 0 and english_hits < 2:
                    return "multilingual"
                return "english"
            return "multilingual"
        except LangDetectException:
            pass

    # 3. Final heuristic fallbacks
    if english_hits >= 2 and ascii_ratio > 0.95:
        return "english"
    if ascii_ratio < 0.85:
        return "multilingual"
    
    return "english"


def language_code_to_display_name(language_code):
    """
    Convert language code to a user-friendly language name.
    """
    if not language_code:
        return "Unknown"

    normalized = str(language_code).strip().lower()
    return LANGUAGE_CODE_TO_NAME.get(normalized, normalized.upper())


def infer_language_name_from_hints(words):
    """
    Infer language name from keyword hits when statistical detector is unavailable
    or uncertain on short text.
    """
    if not words:
        return None

    best_language = None
    best_hits = 0
    for language_name, hint_words in LANGUAGE_HINT_WORDS.items():
        hits = sum(1 for word in words if word in hint_words)
        if hits > best_hits:
            best_language = language_name
            best_hits = hits

    if best_hits >= 2:
        return best_language
    return None


def detect_script_language_name(text):
    """
    Detect language name by Unicode script for non-Latin writing systems.
    """
    hangul_hits = 0
    hiragana_hits = 0
    katakana_hits = 0
    cjk_hits = 0
    devanagari_hits = 0

    for char in text:
        code = ord(char)

        # Korean Hangul blocks
        if 0xAC00 <= code <= 0xD7AF or 0x1100 <= code <= 0x11FF or 0x3130 <= code <= 0x318F:
            hangul_hits += 1
            continue

        # Japanese Hiragana/Katakana (including halfwidth Katakana)
        if 0x3040 <= code <= 0x309F:
            hiragana_hits += 1
            continue
        if 0x30A0 <= code <= 0x30FF or 0xFF66 <= code <= 0xFF9D:
            katakana_hits += 1
            continue

        # Devanagari script (Hindi and related languages)
        if 0x0900 <= code <= 0x097F:
            devanagari_hits += 1
            continue

        # CJK Unified Ideographs (Chinese Han characters, also used in Japanese)
        if 0x4E00 <= code <= 0x9FFF or 0x3400 <= code <= 0x4DBF:
            cjk_hits += 1

    if hangul_hits >= 1:
        return "Korean"
    if hiragana_hits + katakana_hits >= 1:
        return "Japanese"
    if devanagari_hits >= 1:
        return "Hindi (India)"
    if cjk_hits >= 1:
        return "Chinese"

    return None


def detect_text_language_name(text):
    """
    Detect input language and return a user-friendly language name.
    """
    stripped = text.strip()
    if not stripped:
        return "Unknown"

    lowered = stripped.lower()
    script_language = detect_script_language_name(stripped)
    if script_language:
        return script_language

    words = re.findall(r"[a-zA-ZÀ-ỹ]+", lowered)
    vietnamese_hits = sum(1 for word in words if word in VIETNAMESE_HINT_WORDS)
    vietnamese_char_hits = sum(1 for char in lowered if char in VIETNAMESE_UNIQUE_CHARACTERS)

    if vietnamese_char_hits > 0 or vietnamese_hits >= 2:
        return "Vietnamese"

    hinted_language = infer_language_name_from_hints(words)
    if hinted_language:
        return hinted_language

    if HAS_LANGDETECT:
        try:
            detected_lang = langdetect_detect(stripped)
            return language_code_to_display_name(detected_lang)
        except LangDetectException:
            pass

    fallback_language = detect_text_language(stripped)
    if fallback_language == "english":
        return "English"
    if fallback_language == "multilingual":
        return "Multilingual (Mixed/Non-English)"
    return "Unknown"


def choose_best_sentiment_engine(text):
    """
    Choose the most appropriate sentiment engine based on text characteristics.
    """
    language = detect_text_language(text)
    language_name = detect_text_language_name(text)
    lowered = text.lower()
    emoji_count = sum(text.count(emoji_char) for emoji_char in EMOJI_SENTIMENT_MAP)
    social_markers = ("lol", "omg", "haha", "!!!", "??", ":)", ":(", "http://", "https://", "#", "@")
    social_score = sum(marker in lowered for marker in social_markers) + emoji_count
    sentence_count = len(split_sentences(text))

    if language == "multilingual":
        # For Hinglish/Vietnamese with emojis, VADER (with our expansion) 
        # is often more reliable than a transformer that might be confused by code-switching.
        if emoji_count >= 1:
            return {
                "engine": "vader",
                "language": language,
                "language_name": language_name,
                "reason": "Multilingual text with emoji detected; using expanded VADER for reliability.",
            }
            
        if has_multilingual_transformer_support():
            return {
                "engine": "multilingual",
                "language": language,
                "language_name": language_name,
                "reason": "Detected non-English or mixed-language text; using multilingual XLM-R.",
            }
        return {
            "engine": "textblob",
            "language": language,
            "language_name": language_name,
            "reason": "Detected non-English or mixed-language text, but multilingual dependencies are unavailable; using TextBlob fallback.",
        }

    if social_score >= 2 or (emoji_count >= 1 and language == "english"):
        return {
            "engine": "vader",
            "language": language,
            "language_name": language_name,
            "reason": "Detected emoji or social-style text; using VADER.",
        }

    if sentence_count >= 3 and has_transformers_support():
        return {
            "engine": "distilbert",
            "language": language,
            "language_name": language_name,
            "reason": "Detected longer English text; using DistilBERT.",
        }

    return {
        "engine": "textblob",
        "language": language,
        "language_name": language_name,
        "reason": "Using lightweight TextBlob as the best available default.",
    }

# ---------- Tiền xử lý văn bản (Preprocessing) ----------
def normalize_text(text, lowercase=True, remove_punct=True):
    """
    Normalize text by optionally lowercasing and removing punctuation.
    """
    if lowercase:
        text = text.lower()
    
    if remove_punct:
        # Remove all non-letter characters except spaces
        text = re.sub(r"[^a-zA-Z\s]", "", text)
    else:
        # Keep common punctuation when punctuation removal is disabled.
        text = re.sub(r"[^a-zA-Z\s'.,!?;:-]", "", text)
    
    return text.strip()

def preprocess_text(text, custom_stop_words=None):
    """
    Hàm này thực hiện các bước làm sạch văn bản:
    1. Chuyển thành chữ thường.
    2. Loại bỏ các ký tự không phải là chữ cái.
    3. Tách thành các từ.
    4. Loại bỏ các từ dừng (stopwords).
    """
    # Normalize: lowercase and remove punctuation
    text = normalize_text(text, lowercase=True, remove_punct=True)

    # 3. Tách chuỗi văn bản thành một danh sách các từ dựa trên khoảng trắng.
    words = text.split()

    # 4. Lọc bỏ các từ dừng.
    stop_words = custom_stop_words if custom_stop_words is not None else load_stopwords()
    clean_words = []
    for w in words:
        # Chỉ giữ lại những từ không có trong danh sách STOP_WORDS.
        if w not in stop_words:
            clean_words.append(w)

    return clean_words


# ---------- Thống kê từ (Word statistics) ----------
def word_statistics(words):
    """
    Thống kê tần suất xuất hiện của các từ trong một danh sách đã được làm sạch.
    """
    # Use Counter for efficient counting
    freq = Counter(words)

    # Tổng số từ trong danh sách (sau khi đã loại bỏ stopwords).
    total_words = len(words)
    # Số lượng từ duy nhất (không lặp lại), chính là số lượng key trong từ điển tần suất.
    unique_words = len(freq)

    return total_words, unique_words, freq


def top_10_words(freq_dict):
    """
    Tìm ra 10 từ có tần suất xuất hiện cao nhất từ một từ điển tần suất.
    """
    # Use Counter's most_common method for efficient sorting
    if isinstance(freq_dict, Counter):
        return freq_dict.most_common(10)
    else:
        # Fallback for dict input
        items = list(freq_dict.items())
        items.sort(key=lambda x: x[1], reverse=True)
        return items[:10]


def polars_word_frequency(text, top_n=15):
    """
    Compute word frequency with Polars after preprocessing.
    """
    require_polars()
    words = preprocess_text(text)
    if not words:
        return []

    frame = pl.DataFrame({"word": words})
    return (
        frame
        .group_by("word")
        .len()
        .rename({"len": "count"})
        .sort(["count", "word"], descending=[True, False])
        .head(top_n)
        .to_dicts()
    )


def polars_keyword_extraction(text, top_n=10):
    """
    Extract simple top keywords with a Polars scoring heuristic.
    """
    require_polars()
    words = [word for word in preprocess_text(text) if len(word) >= 4]
    if not words:
        return []

    frame = pl.DataFrame({"keyword": words})
    keyword_frame = (
        frame
        .group_by("keyword")
        .len()
        .rename({"len": "count"})
        .with_columns([
            pl.col("keyword").str.len_chars().alias("length"),
            (pl.col("count") * pl.col("keyword").str.len_chars()).alias("score"),
        ])
        .sort(["score", "count", "keyword"], descending=[True, True, False])
        .head(top_n)
    )
    return keyword_frame.to_dicts()


def polars_sentence_analytics(text):
    """
    Analyze sentence lengths with Polars.
    """
    require_polars()
    sentences = split_sentences(text)
    if not sentences:
        return {"summary": {}, "rows": []}

    frame = pl.DataFrame({"sentence": sentences}).with_columns([
        pl.col("sentence").str.len_chars().alias("char_length"),
        pl.col("sentence").str.split(" ").list.len().alias("word_length"),
    ])

    summary = (
        frame
        .select([
            pl.len().alias("sentence_count"),
            pl.col("char_length").mean().round(2).alias("avg_chars"),
            pl.col("word_length").mean().round(2).alias("avg_words"),
            pl.col("char_length").max().alias("max_chars"),
            pl.col("char_length").min().alias("min_chars"),
        ])
        .to_dicts()[0]
    )

    rows = frame.sort("char_length", descending=True).to_dicts()
    return {"summary": summary, "rows": rows}


def _ngram_rows(words, n):
    if len(words) < n:
        return []
    return [" ".join(words[index:index + n]) for index in range(len(words) - n + 1)]


def polars_ngram_frequency(text, top_n=10):
    """
    Compute bigram and trigram frequency with Polars.
    """
    require_polars()
    words = preprocess_text(text)
    bigrams = _ngram_rows(words, 2)
    trigrams = _ngram_rows(words, 3)

    def summarize(items):
        if not items:
            return []
        frame = pl.DataFrame({"ngram": items})
        return (
            frame
            .group_by("ngram")
            .len()
            .rename({"len": "count"})
            .sort(["count", "ngram"], descending=[True, False])
            .head(top_n)
            .to_dicts()
        )

    return {
        "bigrams": summarize(bigrams),
        "trigrams": summarize(trigrams),
    }


def polars_spam_filter(text):
    """
    Flag suspicious sentences with simple spam heuristics using Polars.
    """
    require_polars()
    sentences = split_sentences(text)
    if not sentences:
        return {"spam": [], "clean": []}

    spam_terms = [
        "free", "winner", "win", "urgent", "click", "offer", "buy now",
        "limited time", "guaranteed", "subscribe", "cash", "prize",
    ]
    pattern = "|".join(re.escape(term) for term in spam_terms)
    frame = pl.DataFrame({"sentence": sentences}).with_columns([
        pl.col("sentence").str.to_lowercase().alias("lower_sentence"),
        pl.col("sentence").str.contains(r"https?://|www\.", literal=False).alias("has_link"),
        pl.col("sentence").str.contains(r"(!{2,}|\?{2,})", literal=False).alias("has_excess_punct"),
        pl.col("sentence").str.contains(r"([A-Z]{4,})", literal=False).alias("has_caps_burst"),
        pl.col("sentence").str.contains(pattern, literal=False).alias("has_spam_term"),
    ]).with_columns([
        (
            pl.col("has_link").cast(pl.Int64)
            + pl.col("has_excess_punct").cast(pl.Int64)
            + pl.col("has_caps_burst").cast(pl.Int64)
            + pl.col("has_spam_term").cast(pl.Int64)
        ).alias("spam_score")
    ]).with_columns([
        (pl.col("spam_score") >= 2).alias("is_spam")
    ])

    spam_rows = frame.filter(pl.col("is_spam")).select(["sentence", "spam_score"]).to_dicts()
    clean_rows = frame.filter(~pl.col("is_spam")).select(["sentence"]).to_dicts()
    return {"spam": spam_rows, "clean": clean_rows}


# ---------- Phân tích cảm xúc (Sentiment Analysis) ----------
def sentiment_analysis_textblob(text):
    """
    Phân tích cảm xúc của văn bản bằng TextBlob.
    """
    blob = TextBlob(text)
    sentences = blob.sentences

    result = empty_sentiment_result()

    for s in sentences:
        sentence_text = str(s)
        sentiment_target = get_sentiment_focus_text(sentence_text)
        
        # Expand emojis so TextBlob can see words like "smile", "good", etc.
        blob_text = expand_emojis(sentiment_target)
        polarity = TextBlob(blob_text).sentiment.polarity
        sentiment_type = classify_polarity(polarity)

        result[sentiment_type].append(sentence_text)

    return result


def sentiment_analysis_vader(text):
    """
    Phân tích cảm xúc của văn bản bằng VADER (Valence Aware Dictionary and sEntiment Reasoner).
    VADER rất tốt với ngôn ngữ xã hội và văn bản không chính thức.
    """
    try:
        nltk.data.find('vader_lexicon')
    except LookupError:
        nltk.download('vader_lexicon', quiet=True)
    
    analyzer = SentimentIntensityAnalyzer()
    
    # Split text into sentences
    blob = TextBlob(text)
    sentences = blob.sentences

    result = empty_sentiment_result()

    for s in sentences:
        sentence_text = str(s)
        sentiment_target = get_sentiment_focus_text(sentence_text)
        vader_text = expand_emojis(sentiment_target)
        scores = analyzer.polarity_scores(vader_text)
        compound_score = scores['compound']  # compound score ranges from -1 to 1

        if compound_score >= 0.05:
            sentiment_type = "positive"
        elif compound_score <= -0.05:
            sentiment_type = "negative"
        else:
            sentiment_type = "neutral"

        result[sentiment_type].append(sentence_text)

    return result


def sentiment_analysis_distilbert(text):
    """
    Phân tích cảm xúc của văn bản bằng DistilBERT.
    DistilBERT là một mô hình ngôn ngữ nhẹ dựa trên BERT, phù hợp với xử lý nhanh.
    """
    if not HAS_TRANSFORMERS:
        logger.info("DistilBERT requested but transformers is unavailable; using TextBlob instead.")
        return sentiment_analysis_textblob(text)
    
    try:
        sentiment_pipeline = get_transformers_sentiment_pipeline(DISTILBERT_MODEL_NAME)
        
        # Split text into sentences
        sentences = split_sentences(text)

        result = empty_sentiment_result()

        for s in sentences:
            sentence_text = str(s).strip()
            if not sentence_text:
                continue
            
            # Analyze sentiment (limit text length for efficiency)
            if len(sentence_text) > 512:
                sentence_text = sentence_text[:512]
            
            try:
                sentiment_target = get_sentiment_focus_text(sentence_text)[:512]
                prediction = sentiment_pipeline(sentiment_target)[0]
                sentiment_type = map_transformer_sentiment_label(prediction.get("label", "neutral"))
                result[sentiment_type].append(sentence_text)
            except Exception as e:
                logger.warning("Error analyzing sentence with DistilBERT: %s", e)
                result["neutral"].append(sentence_text)

        return result
    except Exception as e:
        logger.warning("Error initializing DistilBERT, using TextBlob fallback: %s", e)
        # Fallback to TextBlob if DistilBERT fails
        return sentiment_analysis_textblob(text)


def sentiment_analysis_multilingual(text):
    """
    Analyze sentiment for multilingual text with XLM-RoBERTa.
    """
    if not has_transformers_support():
        logger.info("Multilingual sentiment requested but transformers is unavailable; using TextBlob instead.")
        return sentiment_analysis_textblob(text)

    if not has_sentencepiece_support():
        logger.warning("Multilingual sentiment requested but sentencepiece is unavailable; using TextBlob instead.")
        return sentiment_analysis_textblob(text)

    try:
        sentiment_pipeline = get_transformers_sentiment_pipeline(MULTILINGUAL_SENTIMENT_MODEL_NAME)
        sentences = split_sentences(text)

        result = empty_sentiment_result()

        for sentence in sentences:
            sentence_text = str(sentence).strip()
            if not sentence_text:
                continue

            if len(sentence_text) > 512:
                sentence_text = sentence_text[:512]

            try:
                sentiment_target = get_sentiment_focus_text(sentence_text)[:512]
                prediction = sentiment_pipeline(sentiment_target)[0]
                sentiment_type = map_transformer_sentiment_label(prediction.get("label", "neutral"))
                result[sentiment_type].append(sentence_text)
            except Exception as e:
                logger.warning("Error analyzing sentence with multilingual model: %s", e)
                result["neutral"].append(sentence_text)

        return result
    except Exception as e:
        logger.warning("Error initializing multilingual sentiment model, using TextBlob fallback: %s", e)
        return sentiment_analysis_textblob(text)


def sentiment_analysis(text, engine='textblob'):
    """
    Phân tích cảm xúc của văn bản với lựa chọn engine.
    
    Parameters:
    - text: văn bản cần phân tích
    - engine: 'auto', 'textblob' (mặc định), 'vader', 'distilbert', hoặc 'multilingual'
    
    Returns:
    - Dict với keys 'positive', 'neutral', 'negative' chứa danh sách câu
    """
    engine = engine.lower().strip()

    if not text.strip():
        return empty_sentiment_result()

    if engine == 'auto':
        engine = choose_best_sentiment_engine(text)["engine"]
    
    if engine == 'vader':
        return sentiment_analysis_vader(text)
    elif engine == 'distilbert':
        return sentiment_analysis_distilbert(text)
    elif engine == 'multilingual':
        return sentiment_analysis_multilingual(text)
    else:  # textblob is default
        return sentiment_analysis_textblob(text)
