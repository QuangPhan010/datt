import sys
from PyQt5.QtWidgets import (QApplication, QMainWindow, QFileDialog, QMessageBox, 
                             QPushButton, QComboBox, QLabel, QWidget, QVBoxLayout, 
                             QHBoxLayout, QTextEdit, QGridLayout, QFrame, QProgressBar)
from PyQt5.QtCore import Qt, QTimer, QThread, pyqtSignal
from PyQt5.QtGui import QClipboard

# Import module chứa các hàm xử lý ngôn ngữ tự nhiên
import nlp_utils
# Import service layer
from text_analysis_service import TextAnalysisService


# Sentiment Analysis Worker Thread
class SentimentAnalysisWorker(QThread):
    finished = pyqtSignal(dict)
    metadata_ready = pyqtSignal(dict)
    error = pyqtSignal(str)
    
    def __init__(self, text, engine):
        super().__init__()
        self.text = text
        self.engine = engine
    
    def run(self):
        try:
            resolved = (
                nlp_utils.choose_best_sentiment_engine(self.text)
                if self.engine == "auto"
                else {
                    "engine": self.engine,
                    "language": nlp_utils.detect_text_language(self.text),
                    "language_name": nlp_utils.detect_text_language_name(self.text),
                    "reason": f"Using manually selected engine: {self.engine}.",
                }
            )
            self.metadata_ready.emit(resolved)
            result = nlp_utils.sentiment_analysis(self.text, engine=resolved["engine"])
            self.finished.emit(result)
        except Exception as e:
            self.error.emit(str(e))


# Định nghĩa lớp chính của ứng dụng, kế thừa từ QMainWindow
class MainApp(QMainWindow):
    def __init__(self):
        # Gọi hàm khởi tạo của lớp cha (QMainWindow)
        super().__init__()
        
        # Thiết lập cửa sổ chính
        self.setWindowTitle("Smart Text Analyzer – Desktop NLP Application")
        self.setGeometry(100, 100, 1000, 800)
        
        # Tạo central widget và layout chính
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(10, 10, 10, 10)
        main_layout.setSpacing(10)
        
        # ========== SECTION 1: INPUT TEXT & NLP FUNCTIONS ==========
        section1_widget = QWidget()
        section1_layout = QHBoxLayout(section1_widget)
        section1_layout.setSpacing(10)
        
        # Left: Input Text Area
        input_label = QLabel("INPUT TEXT")
        input_label.setStyleSheet("font-weight: bold; color: #333;")
        input_layout = QVBoxLayout()
        input_layout.addWidget(input_label)
        
        self.inputTextEdit = QTextEdit()
        self.inputTextEdit.setPlaceholderText("Enter text here...")
        self.inputTextEdit.setMinimumHeight(150)
        input_layout.addWidget(self.inputTextEdit)
        
        # Label and buttons for text info
        self.infoLabel = QLabel("Lines: 0 | Characters: 0")
        self.infoLabel.setStyleSheet("color: #666; font-size: 10pt;")
        input_layout.addWidget(self.infoLabel)
        
        # File buttons in horizontal layout
        file_buttons_layout = QHBoxLayout()
        self.openFileButton = QPushButton("Open File")
        self.clearButton = QPushButton("Clear Text")
        file_buttons_layout.addWidget(self.openFileButton)
        file_buttons_layout.addWidget(self.clearButton)
        file_buttons_layout.addStretch()
        input_layout.addLayout(file_buttons_layout)
        
        input_widget = QWidget()
        input_widget.setLayout(input_layout)
        input_widget.setMinimumWidth(400)
        section1_layout.addWidget(input_widget, 2)
        
        # Vertical separator
        separator1 = QFrame()
        separator1.setFrameShape(QFrame.VLine)
        separator1.setFrameShadow(QFrame.Sunken)
        section1_layout.addWidget(separator1)
        
        # Right: NLP Functions (Grid)
        nlp_label = QLabel("NLP FUNCTIONS")
        nlp_label.setStyleSheet("font-weight: bold; color: #333;")
        nlp_layout = QVBoxLayout()
        nlp_layout.addWidget(nlp_label)
        
        nlp_grid = QGridLayout()
        nlp_grid.setSpacing(8)
        
        self.stopwordsButton = QPushButton("Remove Stopwords")
        self.top10Button = QPushButton("Top 10 Words")
        self.sentimentButton = QPushButton("Sentiment Analysis")
        self.negativeButton = QPushButton("Negative Sentences")
        self.wordFrequencyButton = QPushButton("Word Frequency")
        self.keywordButton = QPushButton("Keyword Extraction")
        self.sentenceAnalyticsButton = QPushButton("Sentence Analytics")
        self.ngramButton = QPushButton("N-gram Frequency")
        self.spamFilterButton = QPushButton("Spam Filtering")
        
        # Arrange buttons in 5x2 grid
        nlp_grid.addWidget(self.stopwordsButton, 0, 0)
        nlp_grid.addWidget(self.top10Button, 0, 1)
        nlp_grid.addWidget(self.sentimentButton, 1, 0)
        nlp_grid.addWidget(self.negativeButton, 1, 1)
        nlp_grid.addWidget(self.wordFrequencyButton, 2, 0)
        nlp_grid.addWidget(self.keywordButton, 2, 1)
        nlp_grid.addWidget(self.sentenceAnalyticsButton, 3, 0)
        nlp_grid.addWidget(self.ngramButton, 3, 1)
        nlp_grid.addWidget(self.spamFilterButton, 4, 0)
        
        nlp_layout.addLayout(nlp_grid)
        nlp_layout.addStretch()
        
        nlp_widget = QWidget()
        nlp_widget.setLayout(nlp_layout)
        nlp_widget.setMinimumWidth(300)
        section1_layout.addWidget(nlp_widget, 1)
        
        main_layout.addWidget(section1_widget, 1)
        
        # ========== SECTION 2: RESULT VIEW ==========
        section2_widget = QWidget()
        section2_layout = QVBoxLayout(section2_widget)
        
        result_label = QLabel("RESULT VIEW")
        result_label.setStyleSheet("font-weight: bold; color: #333;")
        section2_layout.addWidget(result_label)
        
        self.resultTextEdit = QTextEdit()
        self.resultTextEdit.setReadOnly(True)
        self.resultTextEdit.setMinimumHeight(150)
        section2_layout.addWidget(self.resultTextEdit)
        
        main_layout.addWidget(section2_widget, 1)
        
        # ========== SECTION 3: PROGRESS & STATISTICS PANEL ==========
        section3_widget = QWidget()
        section3_layout = QVBoxLayout(section3_widget)
        
        # Progress bar section (hidden by default)
        progress_label = QLabel("Analyzing sentiment...")
        progress_label.setStyleSheet("font-weight: bold; color: #333;")
        self.progressLabel = progress_label
        self.progressLabel.setVisible(False)
        section3_layout.addWidget(self.progressLabel)
        
        self.progressBar = QProgressBar()
        self.progressBar.setMinimum(0)
        self.progressBar.setMaximum(0)  # Indeterminate progress
        self.progressBar.setMaximumHeight(20)
        self.progressBar.setVisible(False)
        section3_layout.addWidget(self.progressBar)
        
        # Stats label
        stats_label = QLabel("STATISTICS PANEL")
        stats_label.setStyleSheet("font-weight: bold; color: #333;")
        self.statsLabel = stats_label
        section3_layout.addWidget(self.statsLabel)
        self.sentimentInfoLabel = QLabel("Sentiment mode: Auto Detect (Smart)")
        self.sentimentInfoLabel.setStyleSheet("color: #666; font-size: 10pt;")
        section3_layout.addWidget(self.sentimentInfoLabel)
        
        # Sentiment engine selector row
        engine_row_layout = QHBoxLayout()
        engine_label = QLabel("Sentiment Engine:")
        engine_label.setMaximumWidth(150)
        self.sentimentEngineCombo = QComboBox()
        self.sentimentEngineCombo.addItems(["Auto Detect (Smart)", "TextBlob", "VADER", "DistilBERT", "Multilingual XLM-R"])
        self.sentimentEngineCombo.setMaximumWidth(200)
        engine_row_layout.addWidget(engine_label)
        engine_row_layout.addWidget(self.sentimentEngineCombo)
        engine_row_layout.addStretch()
        section3_layout.addLayout(engine_row_layout)
        
        # Copy and Save buttons row
        button_row_layout = QHBoxLayout()
        button_row_layout.addStretch()
        self.copyButton = QPushButton("Copy Result")
        self.saveButton = QPushButton("Save Result")
        self.copyButton.setMaximumWidth(150)
        self.saveButton.setMaximumWidth(150)
        button_row_layout.addWidget(self.copyButton)
        button_row_layout.addWidget(self.saveButton)
        section3_layout.addLayout(button_row_layout)
        
        main_layout.addWidget(section3_widget, 0)
        
        # Store for worker thread
        self.sentiment_worker = None
        self.last_sentiment_resolution = None
        
        # Initialize text analysis service
        self.analysis_service = TextAnalysisService()
        
        # ----- Kết nối các tín hiệu (signals) từ widget tới các hàm xử lý (slots) -----
        self.openFileButton.clicked.connect(self.open_file)
        self.clearButton.clicked.connect(self.clear_text)
        
        # NLP function connections
        self.stopwordsButton.clicked.connect(self.do_remove_stopwords)
        self.top10Button.clicked.connect(self.do_top10)
        self.sentimentButton.clicked.connect(self.do_sentiment)
        self.negativeButton.clicked.connect(self.show_negative_sentences)
        self.wordFrequencyButton.clicked.connect(self.do_word_frequency)
        self.keywordButton.clicked.connect(self.do_keyword_extraction)
        self.sentenceAnalyticsButton.clicked.connect(self.do_sentence_analytics)
        self.ngramButton.clicked.connect(self.do_ngram_frequency)
        self.spamFilterButton.clicked.connect(self.do_spam_filtering)
        
        # Copy and Save connections
        self.copyButton.clicked.connect(self.copy_result)
        self.saveButton.clicked.connect(self.save_result)
        
        # Text change tracking
        self.inputTextEdit.textChanged.connect(self.update_text_info)
        self.sentimentEngineCombo.currentTextChanged.connect(self.update_sentiment_mode_info)
        
        # Initialize button states
        self.update_text_info()
        self.update_sentiment_mode_info()

    def _cleanup_sentiment_worker(self):
        """
        Safely release the worker thread after it finishes.
        """
        if self.sentiment_worker is not None:
            self.sentiment_worker.wait()
            self.sentiment_worker.deleteLater()
            self.sentiment_worker = None

    # -------- Các hàm tiện ích (Utility Methods) --------
    def ensure_input(self):
        """
        Check if input text is not empty. Show message if empty.
        Returns True if input is valid, False otherwise.
        """
        text = self.get_input_text()
        if not text:
            QMessageBox.information(self, "No Input", "Please enter some text to analyze.")
            return False
        return True

    def get_input_text(self):
        """
        Lấy văn bản từ ô nhập liệu (inputTextEdit).
        """
        return self.inputTextEdit.toPlainText().strip()

    def show_result(self, text):
        """
        Hiển thị chuỗi kết quả vào ô hiển thị (resultTextEdit).
        """
        self.resultTextEdit.setPlainText(text)

    # -------- Các hàm xử lý file (File Handling) --------
    def open_file(self):
        """
        Mở một hộp thoại cho phép người dùng chọn một file .txt để mở.
        """
        path, _ = QFileDialog.getOpenFileName(self, "Open file", "", "Text files (*.txt)")
        
        if path:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    self.inputTextEdit.setPlainText(f.read())
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def clear_text(self):
        """
        Xóa toàn bộ văn bản trong cả ô nhập liệu và ô kết quả.
        """
        self.inputTextEdit.clear()
        self.resultTextEdit.clear()

    def copy_result(self):
        """
        Copy the result text to clipboard.
        """
        result_text = self.resultTextEdit.toPlainText()
        if result_text:
            clipboard = QApplication.clipboard()
            clipboard.setText(result_text)
            QMessageBox.information(self, "Copied", "Result copied to clipboard.")
        else:
            QMessageBox.information(self, "No Result", "No result to copy.")

    def save_result(self):
        """
        Save the result text to a file.
        """
        result_text = self.resultTextEdit.toPlainText()
        if not result_text:
            QMessageBox.information(self, "No Result", "No result to save.")
            return

        path, _ = QFileDialog.getSaveFileName(self, "Save Result", "", "Text files (*.txt);;All files (*)")
        if path:
            try:
                with open(path, "w", encoding="utf-8") as f:
                    f.write(result_text)
                QMessageBox.information(self, "Saved", f"Result saved to {path}")
            except Exception as e:
                QMessageBox.critical(self, "Error", str(e))

    def update_text_info(self):
        """
        Cập nhật thông tin về số dòng và số ký tự của văn bản trong ô nhập liệu.
        Also enable/disable NLP buttons based on input availability.
        """
        text = self.inputTextEdit.toPlainText()
        lines = len(text.splitlines())
        chars = len(text)
        self.infoLabel.setText(f"Lines: {lines} | Characters: {chars}")

        # Enable/disable NLP buttons based on whether there's input text
        has_text = bool(text.strip())
        self.stopwordsButton.setEnabled(has_text)
        self.top10Button.setEnabled(has_text)
        self.sentimentButton.setEnabled(has_text)
        self.negativeButton.setEnabled(has_text)
        self.wordFrequencyButton.setEnabled(has_text)
        self.keywordButton.setEnabled(has_text)
        self.sentenceAnalyticsButton.setEnabled(has_text)
        self.ngramButton.setEnabled(has_text)
        self.spamFilterButton.setEnabled(has_text)

    def update_sentiment_mode_info(self):
        """
        Reflect the selected sentiment mode in the status label.
        """
        engine_name = self.sentimentEngineCombo.currentText()
        if engine_name == "Auto Detect (Smart)":
            self.sentimentInfoLabel.setText("Sentiment mode: Auto detect language and choose the best model.")
        else:
            self.sentimentInfoLabel.setText(f"Sentiment mode: Manual - {engine_name}")

    # -------- Các hàm xử lý NLP (NLP functions) --------
    def do_remove_stopwords(self):
        """
        Thực hiện loại bỏ từ dừng (stopwords) và các ký tự đặc biệt.
        """
        if not self.ensure_input():
            return

        text = self.get_input_text()
        words = self.analysis_service.preprocess(text)
        result = self.analysis_service.format_preprocess_result(words)
        self.show_result(result)

    def do_top10(self):
        """
        Tìm và hiển thị 10 từ xuất hiện nhiều nhất trong văn bản.
        """
        if not self.ensure_input():
            return

        text = self.get_input_text()
        top_words = self.analysis_service.get_top_words(text)
        result = self.analysis_service.format_top_words_result(top_words)
        self.show_result(result)

    def do_word_frequency(self):
        """
        Thống kê tần suất từ bằng Polars.
        """
        if not self.ensure_input():
            return

        try:
            text = self.get_input_text()
            rows = self.analysis_service.get_word_frequency(text)
            result = self.analysis_service.format_word_frequency_result(rows)
            self.show_result(result)
        except Exception as e:
            QMessageBox.critical(self, "Word Frequency Error", str(e))

    def do_keyword_extraction(self):
        """
        Trích xuất top keywords bằng Polars.
        """
        if not self.ensure_input():
            return

        try:
            text = self.get_input_text()
            rows = self.analysis_service.get_keywords(text)
            result = self.analysis_service.format_keyword_result(rows)
            self.show_result(result)
        except Exception as e:
            QMessageBox.critical(self, "Keyword Extraction Error", str(e))

    def do_sentence_analytics(self):
        """
        Phân tích độ dài câu bằng Polars.
        """
        if not self.ensure_input():
            return

        try:
            text = self.get_input_text()
            analytics = self.analysis_service.get_sentence_analytics(text)
            result = self.analysis_service.format_sentence_analytics_result(analytics)
            self.show_result(result)
        except Exception as e:
            QMessageBox.critical(self, "Sentence Analytics Error", str(e))

    def do_ngram_frequency(self):
        """
        Thống kê bigram và trigram bằng Polars.
        """
        if not self.ensure_input():
            return

        try:
            text = self.get_input_text()
            ngrams = self.analysis_service.get_ngram_frequency(text)
            result = self.analysis_service.format_ngram_frequency_result(ngrams)
            self.show_result(result)
        except Exception as e:
            QMessageBox.critical(self, "N-gram Frequency Error", str(e))

    def do_spam_filtering(self):
        """
        Lọc các câu có dấu hiệu spam bằng Polars.
        """
        if not self.ensure_input():
            return

        try:
            text = self.get_input_text()
            spam_result = self.analysis_service.filter_spam_sentences(text)
            result = self.analysis_service.format_spam_filter_result(spam_result)
            self.show_result(result)
        except Exception as e:
            QMessageBox.critical(self, "Spam Filtering Error", str(e))

    def do_sentiment(self):
        """
        Phân tích cảm xúc của văn bản, phân loại các câu thành tích cực, tiêu cực, trung tính.
        Sử dụng engine được chọn từ dropdown với progress bar.
        """
        if not self.ensure_input():
            return

        text = self.get_input_text()
        
        # Get selected sentiment engine
        engine_name = self.sentimentEngineCombo.currentText()
        engine_map = {
            "Auto Detect (Smart)": "auto",
            "TextBlob": "textblob",
            "VADER": "vader",
            "DistilBERT": "distilbert",
            "Multilingual XLM-R": "multilingual",
        }
        engine = engine_map.get(engine_name, "textblob")
        
        # Show progress bar
        self.progressLabel.setVisible(True)
        self.progressBar.setVisible(True)
        self.statsLabel.setVisible(False)
        self.sentimentEngineCombo.setEnabled(False)
        self.sentimentButton.setEnabled(False)
        
        # Create and start worker thread
        self.sentiment_worker = SentimentAnalysisWorker(text, engine)
        self.sentiment_worker.metadata_ready.connect(self.on_sentiment_metadata_ready)
        self.sentiment_worker.finished.connect(self.on_sentiment_finished)
        self.sentiment_worker.error.connect(self.on_sentiment_error)
        self.sentiment_worker.start()

    def on_sentiment_metadata_ready(self, metadata):
        """
        Update UI with the resolved sentiment engine before final results arrive.
        """
        self.last_sentiment_resolution = metadata
        engine_name_map = {
            "textblob": "TextBlob",
            "vader": "VADER",
            "distilbert": "DistilBERT",
            "multilingual": "Multilingual XLM-R",
        }
        resolved_name = engine_name_map.get(metadata.get("engine", ""), metadata.get("engine", "Unknown"))
        language = metadata.get("language_name") or metadata.get("language", "unknown")
        reason = metadata.get("reason", "")
        self.sentimentInfoLabel.setText(
            f"Sentiment mode: {resolved_name} | Language: {language} | {reason}"
        )

    def on_sentiment_finished(self, sentiment):
        """
        Callback when sentiment analysis is finished.
        """
        # Hide progress bar
        self.progressLabel.setVisible(False)
        self.progressBar.setVisible(False)
        self.statsLabel.setVisible(True)
        self.sentimentEngineCombo.setEnabled(True)
        self.sentimentButton.setEnabled(True)
        
        # Store result and display
        self.analysis_service.last_sentiment_result = sentiment
        result = self.analysis_service.format_sentiment_result(sentiment)
        self.show_result(result)

        self._cleanup_sentiment_worker()

    def on_sentiment_error(self, error_msg):
        """
        Callback when sentiment analysis encounters an error.
        """
        # Hide progress bar
        self.progressLabel.setVisible(False)
        self.progressBar.setVisible(False)
        self.statsLabel.setVisible(True)
        self.sentimentEngineCombo.setEnabled(True)
        self.sentimentButton.setEnabled(True)
        
        QMessageBox.critical(self, "Sentiment Analysis Error", f"Error: {error_msg}")
        self.update_sentiment_mode_info()

        self._cleanup_sentiment_worker()

    def show_negative_sentences(self):
        """
        Hiển thị danh sách các câu đã được phân loại là tiêu cực.
        """
        negatives = self.analysis_service.get_negative_sentences()
        if not negatives:
            result = "Please run Sentiment Analysis first."
        else:
            result = self.analysis_service.format_negative_sentences_result(negatives)
        self.show_result(result)

    def closeEvent(self, event):
        """
        Wait for the sentiment worker to finish before closing the window.
        """
        if self.sentiment_worker is not None and self.sentiment_worker.isRunning():
            self.progressLabel.setText("Waiting for sentiment analysis to finish...")
            self.sentimentButton.setEnabled(False)
            self.sentiment_worker.wait()
            self._cleanup_sentiment_worker()

        super().closeEvent(event)

# ----- Điểm khởi chạy của chương trình -----
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainApp()
    window.show()
    sys.exit(app.exec_())
